import React, { useState } from "react";
import { IBaseUser } from "./interface";
import { TextField, MaskedTextField } from '@fluentui/react/lib/TextField';

interface IProps {
  onAddUser: (user: IBaseUser) => void;
}
const initUser = { name: "",  designation: "", skills: "", city: "", id: 1 };

const AddUserForm: React.FunctionComponent<IProps> = props => {
  const [formValue, setFormValue] = useState(initUser);
  const onFormSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
          props.onAddUser(formValue);
          setFormValue(initUser);
  };
  const onInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormValue({ ...formValue, [name]: value });
  };
  return (
    <div className="user-form">
      <h1>add users</h1>
      <form className="form-edit" onSubmit={onFormSubmit}>
        <div className="form-row">
          <label>Name</label>
          <input
            type="text"
            placeholder="please input name"
            name="name"
            value={formValue.name}
            onChange={onInputChange}
          />
        </div>
        {/* <TextField label="Name" value={formValue.name} onChange={onInputChange}/>
        <TextField label="Designation" value={formValue.designation} onChange={onInputChange}/> */}
        <div className="form-row">
          <label>Designation</label>
          <input
            type="text"
            placeholder="please input designation"
            name="designation"
            value={formValue.designation}
            onChange={onInputChange}
          />
        </div>
        <div className="form-row">
          <label>Skills</label>
          <input
            type="text"
            placeholder="please skills"
            name="skills"
            value={formValue.skills}
            onChange={onInputChange}
          />
        </div>
        <div className="form-row">
          <button>Add new user</button>
        </div>
      </form>
    </div>
  );
};
export default AddUserForm;
